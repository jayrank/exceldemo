<!DOCTYPE html>
<html>
<header>
<style>
form{
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -100px;
  margin-left: -250px;
  width: 500px;
  height: 200px;
  border: 4px dashed #fff;
}

form input{
  margin: 10 px;
}
form button{
  margin: 0;
  color: #fff;
  background: #16a085;
  border: none;
  width: 508px;
  height: 35px;
  margin-top: 10px;
  margin-left: -4px;
  border-radius: 4px;
  border-bottom: 4px solid #117A60;
  transition: all .2s ease;
  outline: none;
}
form button:hover{
  background: #149174;
	color: #0C5645;
}
form button:active{
  border:0;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

</header>
<body>
<form id="upload_form" action="<?php echo base_url('uploadFile') ?>" method="POST" enctype="multipart/form-data" onsubmit="$('#loading').show();">
  <h1> UPLOAD FILE</h1>
  <input type="file" name="file"  />
  <button type="submit">Upload</button>
  <div id="loading" style="display:none">Uploading...</div>
</form>

</body>

</html>